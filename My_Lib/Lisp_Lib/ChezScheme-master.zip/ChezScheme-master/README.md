Chez Scheme is a compiler and run-time system for the language of
the Revised^6 Report on Scheme (R6RS), with numerous extensions.
The compiler generates native code for each target processor, with
support for x86, x86_64, and 32-bit PowerPC architectures.

Get started by [Building Chez Scheme](BUILDING).
