Sources and builder for AGU 2012 poster. To build, clone this project, then

    cd TeX/
    make
